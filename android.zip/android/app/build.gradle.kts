import java.util.Properties
import java.io.FileInputStream
//buildscript {
//    repositories {
//        google()
//        mavenCentral()
//    }
//    dependencies {
//        classpath("com.google.gms:google-services:4.3.15")
//    }
//}

plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
    //id("com.google.gms.google-services")
    //id("com.google.firebase.crashlytics")
}

android {
    namespace = "com.fanxing.foodorder"
    compileSdk = flutter.compileSdkVersion

    defaultConfig {
        applicationId = "com.fanxing.foodorder"
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        multiDexEnabled = true
    }




    val keystorePropertiesFile = rootProject.file("keystore.properties")
    val keystoreProperties = Properties()
    if (keystorePropertiesFile.exists()) {
        keystorePropertiesFile.inputStream().use {
            keystoreProperties.load(it)
        }
    } else {
        // 如果文件不存在，可以在这里添加警告或错误处理
        println("警告: keystore.properties 文件未找到。请确保文件存在于项目根目录或指定路径。")
    }

    signingConfigs {
        create("release") {
            // 从 keystore.properties 中获取签名信息
            // 注意：storeFile 的路径需要根据您的实际情况进行调整。
            // 这里假设 keystore.properties 中的 storeFile 路径是绝对路径。
            // 如果是相对路径，需要确保其相对于当前模块（app模块）的根目录。
            storeFile = file(keystoreProperties.getProperty("storeFile") ?: "")
            storePassword = keystoreProperties.getProperty("storePassword") ?: ""
            keyAlias = keystoreProperties.getProperty("keyAlias") ?: ""
            keyPassword = keystoreProperties.getProperty("keyPassword") ?: ""

            // 检查是否所有必要的签名属性都已加载
//            if (storeFile == null || storePassword.isEmpty() || keyAlias.isEmpty() || keyPassword.isEmpty()) {
//                println("错误: 签名配置信息不完整。请检查 keystore.properties 文件内容。")
//            }
        }
    }

    buildTypes {
        release {
            // 应用之前定义的 release 签名配置
            signingConfig = signingConfigs.getByName("release")

            // 其他 release 构建类型配置，例如：
            isMinifyEnabled = true // 开启代码混淆
            isShrinkResources = true // 开启资源压缩
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    lint {
        checkReleaseBuilds = false
    }

    sourceSets {
        getByName("main") {
            jniLibs.srcDirs("libs")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }
}

flutter {
    source = "../.."
}

dependencies {
    implementation("androidx.multidex:multidex:2.0.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    //implementation(files("libs/lite-sdk-android-arm-v1.0.8.jar"))
}