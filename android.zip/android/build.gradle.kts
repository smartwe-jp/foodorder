allprojects {
    repositories {
        google()
        mavenCentral()
    }

}

val newBuildDir: Directory = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}

// build.gradle.kts (项目根目录)
buildscript {
    //kotlin_version = '1.8.0'
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // ... 其他依赖
        classpath ("com.google.gms:google-services:4.4.2")
        classpath ("com.android.tools.build:gradle:8.9.1")
        classpath ("com.google.firebase:firebase-crashlytics-gradle:2.9.9")
        classpath ("org.jetbrains.kotlin:kotlin-gradle-plugin:1.8.0")

    }
}
// ...

