Attribute VB_Name = "GloryOpos"
'/////////////////////////////////////////////////////////////////////
'// "ResultCodeExtended" Property Constants for Cash Changer
'/////////////////////////////////////////////////////////////////////
Public Const OPOS_ECHAN_OVERDISPENSE As Long = 1 + OPOSERREXT
Public Const OPOS_ECHAN_TOTALOVER As Long = 2 + OPOSERREXT
Public Const OPOS_ECHAN_CHANGEERROR As Long = 3 + OPOSERREXT
Public Const OPOS_ECHAN_OVER As Long = 4 + OPOSERREXT
Public Const OPOS_ECHAN_IFERROR As Long = 5 + OPOSERREXT
Public Const OPOS_ECHAN_SETERROR As Long = 6 + OPOSERREXT
Public Const OPOS_ECHAN_ERROR As Long = 7 + OPOSERREXT
Public Const OPOS_ECHAN_CHARGING As Long = 8 + OPOSERREXT
Public Const OPOS_ECHAN_NEAREMPTY As Long = 9 + OPOSERREXT
Public Const OPOS_ECHAN_EMPTY As Long = 10 + OPOSERREXT
Public Const OPOS_ECHAN_NEARFULL As Long = 11 + OPOSERREXT
Public Const OPOS_ECHAN_FULL As Long = 12 + OPOSERREXT
Public Const OPOS_ECHAN_OVERFLOW As Long = 13 + OPOSERREXT
Public Const OPOS_ECHAN_REJECT As Long = 14 + OPOSERREXT
Public Const OPOS_ECHAN_BUSY As Long = 15 + OPOSERREXT
Public Const OPOS_ECHAN_ASYNCBUSY As Long = 16 + OPOSERREXT
Public Const OPOS_ECHAN_CASSETTEWAIT As Long = 17 + OPOSERREXT
Public Const OPOS_ECHAN_COLLECTWAIT As Long = 18 + OPOSERREXT
Public Const OPOS_ECHAN_COUNTERROR As Long = 19 + OPOSERREXT
Public Const OPOS_ECHAN_AMOUNTERROR As Long = 20 + OPOSERREXT
Public Const OPOS_ECHAN_IMPOSSIBLE As Long = 21 + OPOSERREXT
Public Const OPOS_ECHAN_CANNOTPAY As Long = 22 + OPOSERREXT
Public Const OPOS_ECHAN_NOTSTORE As Long = 23 + OPOSERREXT
Public Const OPOS_ECHAN_NEAUTRAL As Long = 24 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT As Long = 25 + OPOSERREXT
Public Const OPOS_ECHAN_PAUSEDEPOSIT As Long = 26 + OPOSERREXT
Public Const OPOS_ECHAN_UNMATCH As Long = 27 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_ELSE_BILL As Long = 28 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_ELSE_COIN As Long = 29 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_MOVE_BILL As Long = 30 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_MOVE_COIN As Long = 31 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_ERR_BILL As Long = 32 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_ERR_COIN As Long = 33 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_RJ_BILL As Long = 34 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_RJ_COIN As Long = 35 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_CAS_BILL As Long = 36 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_OVF_COIN As Long = 37 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_SET_BILL As Long = 38 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_SET_COIN As Long = 39 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_RESET_BILL As Long = 40 + OPOSERREXT
Public Const OPOS_ECHAN_DEPOSIT_RESET_COIN As Long = 41 + OPOSERREXT

' /////////////////////////////////////////////////////////////////////
' // DirectIO Method Constants
' /////////////////////////////////////////////////////////////////////
Public Const CHAN_DI_RESET As Long = 1&
Public Const CHAN_DI_MEMREAD As Long = 2&
Public Const CHAN_DI_MEMCLEAR As Long = 3&
Public Const CHAN_DI_CHGMODE As Long = 4&
Public Const CHAN_DI_SSWSET As Long = 5&
Public Const CHAN_DI_TIMESET As Long = 6&
Public Const CHAN_DI_ENQ As Long = 7&
Public Const CHAN_DI_STRING As Long = 8&
Public Const CHAN_DI_COLLECT As Long = 9&
Public Const CHAN_DI_STATUSREAD As Long = 10&
Public Const CHAN_DI_SUPPLYCOUNTS As Long = 11&
Public Const CHAN_DI_SEISA As Long = 12&
Public Const CHAN_DI_DEPOSITDATAREAD As Long = 13&
Public Const CHAN_DI_BEGINDEPOSIT As Long = 14&
Public Const CHAN_DI_ENDDEPOSIT As Long = 15&
Public Const CHAN_DI_PAUSEDEPOSIT As Long = 16&
Public Const CHAN_DI_RESTARTDEPOSIT As Long = 17&
Public Const CHAN_DI_DEPOSITMODE As Long = 18&
Public Const CHAN_DI_COUNTCLR As Long = 19&
Public Const CHAN_DI_GETLOG As Long = 20&
Public Const CHAN_DI_OPENDRAWER As Long = 21&
Public Const CHAN_DI_CHILDLOCK As Long = 22&
Public Const CHAN_DI_ERRGUIDANCE As Long = 101&

' /////////////////////////////////////////////////////////////////////
' // DirectIO Event Constants
' /////////////////////////////////////////////////////////////////////
Public Const CHAN_DIEVT_CASSETTEWAIT As Long = 1
Public Const CHAN_DIEVT_CHARGING As Long = 2
Public Const CHAN_DIEVT_DEPOSITERROR As Long = 3
Public Const CHAN_DIEVT_DEPOSITRJ As Long = 4
Public Const CHAN_DIEVT_DEPOSITCASSETTEFULL As Long = 5
Public Const CHAN_DIEVT_DEPOSITSETERROR As Long = 6
Public Const CHAN_DIEVT_PULLOUT As Long = 7
Public Const CHAN_DIEVT_DEPOSITREADY As Long = 8

' /////////////////////////////////////////////////////////////////////
' // OpenResult Constants
' /////////////////////////////////////////////////////////////////////
Public Const OPOS_ORS_SPECIFIC& = 450
Public Const OPOS_ORS_EVENTCLASS As Long = OPOS_ORS_SPECIFIC + 1
Public Const OPOS_ORS_COCREATE As Long = OPOS_ORS_SPECIFIC + 2
Public Const OPOS_ORS_PORTCONTROL As Long = OPOS_ORS_SPECIFIC + 3
Public Const OPOS_ORS_EVENTTHREAD As Long = OPOS_ORS_SPECIFIC + 4
Public Const OPOS_ORS_SENSETHREAD As Long = OPOS_ORS_SPECIFIC + 5
