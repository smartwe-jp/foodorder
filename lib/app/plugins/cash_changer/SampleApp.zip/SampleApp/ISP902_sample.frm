VERSION 5.00
Object = "{CCB90030-B81E-11D2-AB74-0040054C3719}#1.0#0"; "OPOSCashChanger.ocx"
Begin VB.Form frmMain 
   BorderStyle     =   3  '????????
   Caption         =   "SAMPLE"
   ClientHeight    =   7380
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   9600
   BeginProperty Font 
      Name            =   "?l?r ?o?S?V?b?N"
      Size            =   12
      Charset         =   128
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   492
   ScaleMode       =   3  '????
   ScaleWidth      =   640
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  '???????
   Begin VB.CommandButton BtnSubTotal 
      Caption         =   "???v"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   750
      Left            =   2760
      TabIndex        =   19
      Top             =   1560
      Width           =   2250
   End
   Begin VB.CommandButton BtnBack 
      Caption         =   "?I??"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   630
      Left            =   7440
      TabIndex        =   18
      Top             =   6600
      Width           =   1770
   End
   Begin VB.CommandButton BtnErrorRestore 
      Caption         =   "?G???[????"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   750
      Left            =   360
      TabIndex        =   17
      Top             =   5880
      Width           =   2250
   End
   Begin VB.TextBox TxtChange 
      Alignment       =   1  '?E????
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   15.75
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Left            =   7080
      TabIndex        =   16
      Top             =   2670
      Width           =   2175
   End
   Begin VB.OptionButton RAD_RT
      Caption         =   "RAD/RT???"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   6240
      TabIndex        =   12
      Top             =   3600
      Width           =   2175
   End
   Begin VB.OptionButton RT_ONLY 
      Caption         =   "RT?P????"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   6240
      TabIndex        =   13
      Top             =   4080
      Width           =   2055
   End
   Begin VB.CommandButton BtnBatchCollection 
      Caption         =   "?S???"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   750
      Left            =   2760
      TabIndex        =   11
      Top             =   4800
      Width           =   2250
   End
   Begin VB.CommandButton BtnCashBalanceShowing 
      Caption         =   "????\??"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   750
      Left            =   360
      TabIndex        =   10
      Top             =   4800
      Width           =   2250
   End
   Begin VB.TextBox TxtDepositAmount 
      Alignment       =   1  '?E????
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   15.75
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Left            =   7080
      TabIndex        =   8
      Top             =   1800
      Width           =   2175
   End
   Begin VB.CommandButton BtnDepositRepay 
      Caption         =   "?L?????Z??"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   750
      Left            =   2760
      TabIndex        =   7
      Top             =   2520
      Width           =   2250
   End
   Begin VB.TextBox TxtItemsPrice 
      Alignment       =   1  '?E????
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   15.75
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      IMEMode         =   3  '????
      Left            =   7080
      TabIndex        =   5
      Top             =   1080
      Width           =   2175
   End
   Begin VB.CommandButton BtnDispensingMoney 
      Caption         =   "??i????"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   750
      Left            =   360
      TabIndex        =   4
      Top             =   3480
      Width           =   2250
   End
   Begin VB.CommandButton BtnCurrentTotal 
      Caption         =   "???v"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   750
      Left            =   360
      TabIndex        =   3
      Top             =   2520
      Width           =   2250
   End
   Begin VB.CommandButton BtnDepositCounting 
      Caption         =   "?X?L?????J?n"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   750
      Left            =   360
      TabIndex        =   2
      Top             =   1560
      Width           =   2250
   End
   Begin VB.CommandButton BtnClosure 
      Caption         =   "�Ǐ���"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   750
      Left            =   2760
      TabIndex        =   1
      Top             =   240
      Width           =   2250
   End
   Begin VB.CommandButton BtnStartUp 
      Caption         =   "�J�Ǐ���"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   750
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   2250
   End
   Begin VB.Frame Frame1 
      Caption         =   "??????"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1575
      Left            =   6000
      TabIndex        =   14
      Top             =   3240
      Width           =   2535
   End
   Begin VB.Frame Frame2 
      Caption         =   "?G???[?????N??"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1575
      Left            =   6000
      TabIndex        =   20
      Top             =   4920
      Width           =   2535
      Begin VB.OptionButton ERR_MANUAL 
         Caption         =   "?????"
         BeginProperty Font 
            Name            =   "?l?r ?S?V?b?N"
            Size            =   12
            Charset         =   128
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Left            =   240
         TabIndex        =   22
         Top             =   840
         Width           =   2055
      End
      Begin VB.OptionButton ERR_AUTO 
         Caption         =   "?????N??????"
         BeginProperty Font 
            Name            =   "?l?r ?S?V?b?N"
            Size            =   12
            Charset         =   128
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Left            =   240
         TabIndex        =   21
         Top             =   360
         Width           =   2175
      End
   End
   Begin OposCashChanger_CCOCtl.OPOSCashChanger OPOSCashChanger1 
      Left            =   5520
      OleObjectBlob   =   "ISP902_sample.frx":0000
      Top             =   360
   End
   Begin VB.Line Line1 
      X1              =   360
      X2              =   632
      Y1              =   168
      Y2              =   168
   End
   Begin VB.Label Label3 
      Caption         =   "?????"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   5880
      TabIndex        =   15
      Top             =   2760
      Width           =   1215
   End
   Begin VB.Label Label2 
      Caption         =   "?a??????z"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   5400
      TabIndex        =   9
      Top             =   1800
      Width           =   1815
   End
   Begin VB.Label Label1 
      Caption         =   "???i???v?z"
      BeginProperty Font 
         Name            =   "?l?r ?S?V?b?N"
         Size            =   14.25
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   5400
      TabIndex        =   6
      Top             =   1200
      Width           =   1575
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Declare Function ClientToScreen Lib "user32" (ByVal hwnd As Long, lpPoint As Point) As Long

Private Type Point
        X As Long
        Y As Long
End Type

'?J?????
Private Sub BtnStartUp_Click()
    Dim lngRet As Long
On Error Resume Next

    'Open???\?b?h????s?i?f?o?C?X???I?[?v??????j
    gfncOposLog "Open", True, "CashChanger", Me.Name, "", ""
    lngRet = OPOSCashChanger1.Open("CashChanger")
    gfncOposLog "Open", False, "????R?[?h?F" & lngRet, Me.Name, "", ""

    '????J???????????????s????
    If lngRet = OposEIllegal Then
        lngRet = OposSuccess
    End If
    
    Select Case lngRet
    Case OposSuccess
        If OPOSCashChanger1.Claimed = False Then
            'ClaimDevice???\?b?h????s (?r???A?N?Z?X???l??(?????????10?b))
            gfncOposLog "ClaimDevice", True, "10000", Me.Name, "", ""
            lngRet = OPOSCashChanger1.ClaimDevice(10000)
            gfncOposLog "ClaimDevice", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
            Select Case lngRet
            Case OposSuccess
                '?v???p?e?B????
                OPOSCashChanger1.DeviceEnabled = True
                OPOSCashChanger1.DataEventEnabled = True
                OPOSCashChanger1.FreezeEvents = False
                'DirectIO???\?b?h????s?i?a??????v?????[?h???X?j
                gfncOposLog "CHAN_DI_DEPOSITMODE", True, "", Me.Name, "", ""
                lngRet = OPOSCashChanger1.DirectIO(CHAN_DI_DEPOSITMODE, &H101, "")
                gfncOposLog "CHAN_DI_DEPOSITMODE", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
            Case Else
                MsgBox ("?J?????????s????????B????????m?F??????????B")
                Exit Sub
            End Select
        Else
            '?v???p?e?B????
            OPOSCashChanger1.DeviceEnabled = True
            OPOSCashChanger1.DataEventEnabled = True
            OPOSCashChanger1.FreezeEvents = False
        End If
        
        '?t?H?[????\???X?V????
        BtnStartUp.Enabled = False
        BtnClosure.Enabled = True
        BtnDepositCounting.Enabled = True
        BtnSubTotal.Enabled = False
        BtnCurrentTotal.Enabled = False
        BtnDispensingMoney.Enabled = True
        BtnDepositRepay.Enabled = False
        BtnCashBalanceShowing.Enabled = True
        BtnBatchCollection.Enabled = True
        BtnErrorRestore.Enabled = True

        TxtItemsPrice.Enabled = False
        
    Case Else
        MsgBox ("?J?????????s????????B????????m?F??????????B")
    End Select
    
End Sub

'??????
Private Sub BtnClosure_Click()
    Dim lngRet As Long
On Error Resume Next

    If OPOSCashChanger1 Is Nothing Then
        Exit Sub
    End If
    
    '?v???p?e?B????
    OPOSCashChanger1.DeviceEnabled = False
    
    'ReleaseDevice???\?b?h????s?i?r???I?A?N?Z?X???J???j
    gfncOposLog "ReleaseDevice", True, "", Me.Name, "", ""
    lngRet = OPOSCashChanger1.ReleaseDevice
    gfncOposLog "ReleaseDevice", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
    
    '???b?Z?[?W???????????????I???????
    DoEvents
    
    'Close???\?b?h????s?i?f?o?C?X???????\?[?X??????j
    gfncOposLog "Close", True, "", Me.Name, "", ""
    lngRet = OPOSCashChanger1.Close
    gfncOposLog "Close", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
    
    '??????
    Call Form_Load
    
End Sub


'?I??????
Private Sub BtnBack_Click()
    Unload Me   '?_?C?A???O??????
End Sub

' ?@?\?@?@?@: ?X?L?????J?n?{?^???????
'
' ???l?@?@: ???
'
' ?????@?@?@: ???
'
' ?@?\?????@: ??????t???J?n????
'
' ???l?@?@?@: ?????GetCash?C?x???g????DepositCount?v???p?e?B?????
Private Sub BtnDepositCounting_Click()
    Dim lngRet As Long

    If OPOSCashChanger1 Is Nothing Then
        Exit Sub
    End If
    
    
    '?v???p?e?B????
    OPOSCashChanger1.DataEventEnabled = True
    
    '???????z?E?o?????z?N???A
    ClearArray mlngDepositCount()
    ClearArray mlngDispenseCount()
    
    'BeginDeposit???\?b?h????s?i?v???????J?n?j
    gfncOposLog "BeginDeposit", True, "", Me.Name, "", ""
    lngRet = OPOSCashChanger1.BeginDeposit
    gfncOposLog "BeginDeposit", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
    
    '???\?b?h???s?????m?F
    Select Case OPOSCashChanger1.ResultCode
    Case OposSuccess
        menmStatus = GE_CASHCHANGER_STATUS_DEPOSIT
        BeginDeposit = True
        '?t?H?[????\???X?V????
        BtnDepositCounting.Enabled = False
        BtnDispensingMoney.Enabled = False
        BtnBatchCollection.Enabled = False
        BtnSubTotal.Enabled = True
        TxtItemsPrice.Text = 0
        TxtItemsPrice.Enabled = True
        TxtDepositAmount.Text = 0
        TxtChange.Text = 0
    Case OposEIllegal
        Select Case OPOSCashChanger1.ResultCodeExtended
        Case OPOS_ECHAN_DEPOSIT, OPOS_ECHAN_PAUSEDEPOSIT
            menmStatus = GE_CASHCHANGER_STATUS_DEPOSIT
            '????v????
            BtnSubTotal.Enabled = True
            TxtItemsPrice.Enabled = True
           menmErrStatus = GE_CASHCHANGER_ERROR_ALREADYDEPOSIT
        Case Else
            menmErrStatus = GE_CASHCHANGER_ERROR_ELSE
        End Select
    Case Else
        menmErrStatus = GE_CASHCHANGER_ERROR_ELSE
    End Select

End Sub


' ?@?\?@?@?@: ???v?{?^???????
'
'
' ?@?\?????@: ???i???v???z???m????
'
' ???l?@?@?@:
Private Sub BtnSubTotal_Click()
    Dim response As Integer
    '???i???v?z?????
    response = MsgBox("???i???v?z???m??????B", vbYesNo, "???i???v?z??m??")

    '???i???v???m???????A?????????J??
    If response = vbYes Then
        '?t?H?[????\???X?V????
        TxtItemsPrice.Enabled = False
        BtnSubTotal.Enabled = False
        BtnCurrentTotal.Enabled = True
        BtnDepositRepay.Enabled = True
    Else
    
    End If
End Sub

' ?@?\?@?@?@: ???v?????
'
' ???l?@?@: ???
'
' ?????@?@?@: ???
'
' ?@?\?????@: ?????v??????????I??????
'
' ???l?@?@?@:

Private Sub BtnCurrentTotal_Click()
    Dim lngRet As Long
    Dim lngChange As Long
    Dim intSuc As Integer

    If OPOSCashChanger1 Is Nothing Then
        Exit Sub
    End If

'   ???i???v????????????????????b?Z?[?W??m
    If (Trim(TxtItemsPrice.Text) = "") Then
        MsgBox "???i???v???????????????"
        '?t?H?[????\???X?V????
        TxtItemsPrice.Enabled = True
        BtnSubTotal.Enabled = True
        BtnCurrentTotal.Enabled = False
        BtnDepositRepay.Enabled = False
        Exit Sub
    End If
    
    
'   FixDeposit???\?b?h????s?i?v???m?????j
    gfncOposLog "FixDeposit", True, "", Me.Name, "", ""
    lngRet = OPOSCashChanger1.FixDeposit
    gfncOposLog "FixDeposit", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
    
    '???\?b?h???s?????m?F
    Select Case OPOSCashChanger1.ResultCode
    Case OposSuccess
        menmStatus = GE_CASHCHANGER_STATUS_FIXED
        '?a??????z????
        lngAmount = OPOSCashChanger1.DepositAmount
        '?a???????\???X?V
        TxtDepositAmount.Text = Format(lngAmount, "#,##0")
    
        '?????o?????z??Z?o(?a??????z?|???i???i)
        lngChange = CLng(TxtDepositAmount.Text) - CLng(TxtItemsPrice.Text)
     
        'EndDeposit???\?b?h??p?????[?^??f
        Select Case lngChange
        Case Is > 0
            intSuc = ChanDepositChange&
            BtnDispensingMoney.Enabled = True
        Case 0
            intSuc = ChanDepositNochange&
        Case Is < 0
            '?a??????z???s?????????????A??p????
            MsgBox ("???z?s?????A?a??????z???p??????B")
            intSuc = ChanDepositrepay&
        End Select
        
    Case Else
        ' ?O??Fix?????E??????End?????s?????????????A
        ' ???o??????????????p??????
        intSuc = ChanDepositNochange&
        
    End Select
    
 
    'EndDeposit???\?b?h????s?i?v???????I???j
    gfncOposLog "EndDeposit", True, intSuc, Me.Name, "", ""
    lngRet = OPOSCashChanger1.EndDeposit(intSuc)
    gfncOposLog "EndDeposit", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
    
    '???\?b?h???s?????m?F
    Select Case OPOSCashChanger1.ResultCode
    Case OposSuccess
        menmStatus = GE_CASHCHANGER_STATUS_CONNECT
        '?t?H?[????\???X?V????
        BtnDepositCounting.Enabled = True
        BtnCurrentTotal.Enabled = False
        BtnDispensingMoney.Enabled = True
        BtnDepositRepay.Enabled = False
        BtnClosure.Enabled = True
        BtnBatchCollection.Enabled = True
    Case Else
        Select Case OPOSCashChanger1.ResultCodeExtended
        Case OPOS_ECHAN_DEPOSIT
            '?v????????
            menmErrStatus = GE_CASHCHANGER_ERROR_FIXING
        Case Else
            menmErrStatus = GE_CASHCHANGER_ERROR_ELSE
        End Select
    End Select
    
    '???K?L??????A?????o?????????s??
    If (intSuc = ChanDepositChange&) Then
        '??K?z??Z?b?g
        TxtChange.Text = Format(lngChange, "#,##0")
        '?v???p?e?B????i???o??????j
        OPOSCashChanger1.CurrentExit = 1
        'DispenseChange???\?b?h????s?i???K???o?????j
        gfncOposLog "DispenseChange", True, lngChange, Me.Name, "", ""
        lngRet = OPOSCashChanger1.DispenseChange(lngChange)
        gfncOposLog "DispenseChange", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
        
        '???o?????I??
        Select Case OPOSCashChanger1.ResultCode
        Case OposSuccess
            menmStatus = GE_CASHCHANGER_STATUS_CONNECT
            '?t?H?[????\???X?V????
            BtnClosure.Enabled = True
            BtnDispensingMoney.Enabled = True
            BtnBatchCollection.Enabled = True
        Case Else
            menmErrStatus = GE_CASHCHANGER_ERROR_ELSE
        End Select
    End If
    
End Sub

' ?@?\?@?@?@: ??i????
'
' ???l?@?@: ???
'
' ?????@?@?@: ???
'
' ?@?\?????@: ????????v???z????????A?????o?????s??
'
' ???l?@?@?@:
Private Sub BtnDispensingMoney_Click()
      
    '????????p?t?H?[?????J??
    frmReturn.Show

End Sub

' ?@?\?@?@?@: ?a??????z???p
'
' ???l?@?@: ???
'
' ?????@?@?@: ???
'
' ?@?\?????@: ?????v??????????I?????A?a????????p????
'
' ???l?@?@?@:
Private Sub BtnDepositRepay_Click()
    Dim lngRet As Long
    Dim lngChange As Long
    Dim intSuc As Integer

    If OPOSCashChanger1 Is Nothing Then
        Exit Sub
    End If
        
'   FixDeposit???\?b?h????s?i?v???m?????j
    gfncOposLog "FixDeposit", True, "", Me.Name, "", ""
    lngRet = OPOSCashChanger1.FixDeposit
    gfncOposLog "FixDeposit", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
    
    '???\?b?h???s?????m?F
    Select Case lngRet
    Case OposSuccess
        menmStatus = GE_CASHCHANGER_STATUS_FIXED
    Case Else
        Select Case OPOSCashChanger1.ResultCodeExtended
        Case OPOS_ECHAN_DEPOSIT
            '?v????????
            menmErrStatus = GE_CASHCHANGER_ERROR_FIXING
        Case Else
            menmErrStatus = GE_CASHCHANGER_ERROR_ELSE
        End Select
        ' ?O??Fix?????E??????End?????s?????????????A
        ' ???????p??????
        
    End Select
    
'   EndDeposit???\?b?h????s?i??p?????j
    gfncOposLog "EndDeposit", True, "", Me.Name, "", ""
    lngRet = OPOSCashChanger1.EndDeposit(ChanDepositrepay&)
    gfncOposLog "EndDeposit", False, "????R?[?h?F" & lngRet, Me.Name, "", ""

    '???o?????I??
    Select Case lngRet
    Case OposSuccess
        menmStatus = GE_CASHCHANGER_STATUS_CONNECT
        '?t?H?[????\???X?V????
        BtnClosure.Enabled = True
        BtnDepositCounting.Enabled = True
        BtnCurrentTotal.Enabled = False
        BtnDispensingMoney.Enabled = True
        BtnDepositRepay.Enabled = False
        BtnBatchCollection.Enabled = True
        lngAmount = 0
        TxtItemsPrice.Text = 0
        TxtDepositAmount.Text = 0
    Case Else
        Select Case OPOSCashChanger1.ResultCodeExtended
        Case OPOS_ECHAN_DEPOSIT
            '?v????????
            menmErrStatus = GE_CASHCHANGER_ERROR_FIXING
        Case Else
            menmErrStatus = GE_CASHCHANGER_ERROR_ELSE
        End Select
    End Select
End Sub

' ?@?\?@?@?@: ??????(????)????
'
' ???l?@?@: ???
'
' ?????@?@?@: ???
'
' ?@?\?????@: ??????(????)???????s???v???p?e?B??i?[????
'
' ???l?@?@?@: ?????CashCount?v???p?e?B????????
    
Private Sub BtnCashBalanceShowing_Click()

    Dim lngRet As Long                ' ???l
     
    Dim st_CashCounts As String     'CashCounts??????
    Dim b_Discrepancy As Boolean
    
    Dim st_BillCashList As String   ' ????????????i?[?p
    Dim st_CoinCashList As String   ' ?d?????????i?[?p
   
    Dim i_FindIdx As Integer
  
        
    'ReadCashCounts???\?b?h????s?i??????????)
    gfncOposLog "ReadCashCounts", True, "", Me.Name, "", ""
    lngRet = OPOSCashChanger1.ReadCashCounts(st_CashCounts, b_Discrepancy)
    gfncOposLog "ReadCashCounts", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
     
    ' ";"???u??????
    i_FindIdx = InStr(1, st_CashCounts, ";")

    ' ?d??????????????????????
    If 0 < i_FindIdx Then
        st_CoinCashList = Left(st_CashCounts, i_FindIdx - 1)
        st_BillCashList = Mid(st_CashCounts, i_FindIdx + 1)
    Else
        st_CoinCashList = st_CashCounts
        st_BillCashList = ""
    End If
          
    If 0 <> Len(st_BillCashList) Then
        Call SetKinsyuMai(st_BillCashList, frmCashCounts.lblBillkinsyu, frmCashCounts.TxtBillMai, frmCashCounts.lblBillkinsyu.UBound)
    End If
    
    Call SetKinsyuMai(st_CoinCashList, frmCashCounts.lblCoinkinsyu, frmCashCounts.TxtCoinMai, frmCashCounts.lblCoinkinsyu.UBound)
        
          
    '????\???p?t?H?[?????J??
    frmCashCounts.Show vbModal

    
End Sub

' ?@?\?@?@?@: ?S???????
'
' ???l?@?@: Boolean, True(????) or False(???s)
'
' ?????@?@?@: ?????A?d??????L??
'
' ?@?\?????@: ?S??????????s???B
'
' ???l?@?@?@:
Private Sub BtnBatchCollection_Click()
    Dim blnRet As Boolean
    Dim bill As Boolean, coin As Boolean
    Dim DeviceChk As Integer
    
    '??????????
    If (RAD_RT.Value = True) Then
        DeviceChk = MsgBox("???????RAD/RT????????????B", vbYesNo, "???????m?F")
        bill = True
        coin = True
    Else
        DeviceChk = MsgBox("???????RT????????????B", vbYesNo, "???????m?F")
        bill = False
        coin = True
    End If
    
    If (DeviceChk = vbYes) Then
        If OPOSCashChanger1 Is Nothing Then
            Exit Sub
        End If
    
        '?S???
        If Not CollectAll(bill, coin) Then
            Exit Sub
        End If
    Else
        MsgBox ("????????X???A??x???s????????????B")
        
    End If

End Sub


' ?@?\?@?@?@: ?G???[?????{?^??????
'
'
' ?@?\?????@: ?G???[?????K?C?_???X???N??????B
'
' ???l?@?@?@:
Private Sub BtnErrorRestore_Click()
    Dim lngData As Long
    Dim lngRet As Long
    Dim strTemp As String

    '?????|?b?v?A?b?v
    lngData = 1
    
    ' ?\????u???????
    strTemp = GetErrGuidancePos()

    'DirectIO???\?b?h????s?i?G???[?????K?C?_???X??N???j
    gfncOposLog "DirectIO CHAN_DI_ERRGUIDANCE", True, "", Me.Name, "", ""
    lngRet = OPOSCashChanger1.DirectIO(CHAN_DI_ERRGUIDANCE, lngData, strTemp)
    gfncOposLog "DirectIO CHAN_DI_ERRGUIDANCE", False, "????R?[?h?F" & lngRet, Me.Name, "", ""


End Sub

' ?@?\?@?@?@: ?G???[?????\????u???????
'
' ???l?@?@: String ????????????
'
' ?????@?@?@: ???
'
' ?@?\?????@: ?G???[?????K?C?_???X?\????u?w?????????????B
'
' ???l?@?@?@:
Private Function GetErrGuidancePos() As String
    
    '?t?H?[????\?????W??????i?s?N?Z??????j
    Dim LeftData As Long
    Dim TopData As Long
    Dim ScreenPoint As Point
    
    ClientToScreen frmMain.hwnd, ScreenPoint
    LeftData = ScreenPoint.X
    TopData = ScreenPoint.Y
             
   '?\????u(Main?_?C?A???O???\??????)
    GetErrGuidancePos = LeftData & "," & TopData

End Function
'��������
Private Sub Form_Load()
    '?t?H?[????e?R???g???[?????????
    'UI��?���n��
    BtnStartUp.Enabled = True
    BtnClosure.Enabled = True
    BtnDepositCounting.Enabled = False
    BtnCurrentTotal.Enabled = False
    BtnDispensingMoney.Enabled = False
    BtnDepositRepay.Enabled = False
    BtnCashBalanceShowing.Enabled = False
    BtnBatchCollection.Enabled = False
    BtnErrorRestore.Enabled = False
    BtnSubTotal.Enabled = False
        
    TxtItemsPrice.Text = 0
    TxtDepositAmount.Text = 0
    TxtChange.Text = 0
    
    TxtItemsPrice.Enabled = False
    TxtDepositAmount.Enabled = False
    TxtChange.Enabled = False
        
    RAD_RT.Value = True
    ERR_AUTO.Value = True
    '�Q�����n�� modFunc Setup()
    Setup
    
End Sub

' ?@?\?@?@?@: DataEvent???m
'
' ???l?@?@: ???
'
' ?????@?@?@: Status, I, Long, ?X?e?[?^?X
'
' ?@?\?????@: ?a??????z??\???E?X?V???????s???B
'
' ???l?@?@?@:
Private Sub OPOSCashChanger1_DataEvent(ByVal Status As Long)
   
    Dim lngRet As Long
    Dim lngAmount As Long
    
    If menmStatus = GE_CASHCHANGER_STATUS_DEPOSIT Then
        '?v???p?e?B?????i?a??????z?????j
        lngAmount = OPOSCashChanger1.DepositAmount
        '?a???????\???X?V????
        TxtDepositAmount.Text = Format(lngAmount, "#,##0")
        
    End If
    
End Sub

' ?@?\?@?@?@: ?S???
'
' ???l?@?@: Boolean, True(????) or False(???s)
'
' ?????@?@?@: blnBill, I, Boolean, True(???????????) or False(??????????)
' ?@?@?@?@?@: blnCoin, I, Boolean, True(?d????????) or False(?d???????)
'
' ?@?\?????@: ?S??????s??
'
' ???l?@?@?@:
Public Function CollectAll(Optional ByVal blnBill As Boolean = True, Optional ByVal blnCoin As Boolean = True) As Boolean
    
    Dim lngRet As Long
    Dim lngData As Long

    CollectAll = False

    lngData = &H0
    If blnBill = True Then
        lngData = lngData Or &H3
    End If
    If blnCoin = True Then
        lngData = lngData Or &H70000
    End If
    
    'DirectIO???\?b?h????s?i?S????????j
    gfncOposLog "DirectIO CHAN_DI_COLLECT", True, "", Me.Name, "", ""
    lngRet = OPOSCashChanger1.DirectIO(CHAN_DI_COLLECT, lngData, "")
    gfncOposLog "DirectIO CHAN_DI_COLLECT", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
    
    Select Case OPOSCashChanger1.ResultCode
    Case OposSuccess
        CollectAll = True
    Case OposEExtended
        Select Case OPOSCashChanger1.ResultCodeExtended
        Case OPOS_ECHAN_OVERDISPENSE
            '????I?[?o?[
            menmErrStatus = GE_CASHCHANGER_ERROR_NOCHANGE
        Case OPOS_ECHAN_OVER
            '???z???I?[?o?[
            menmErrStatus = GE_CASHCHANGER_ERROR_OVER
        Case OPOS_ECHAN_SETERROR, OPOS_ECHAN_ERROR, OPOS_ECHAN_BUSY
            '?Z?b?g?O??E?????@???E?????@????
            menmErrStatus = GE_CASHCHANGER_ERROR_CHANGER
        Case Else
            menmErrStatus = GE_CASHCHANGER_ERROR_ELSE
        End Select
    Case Else
        menmErrStatus = GE_CASHCHANGER_ERROR_ELSE
    End Select

End Function



Private Sub ItemsPrice_GotFocus()
    Me.TxtItemsPrice.SelStart = 0
    Me.TxtItemsPrice.SelLength = Len(Me.TxtItemsPrice.Text)
End Sub

Private Sub TxtItemsPrice_LostFocus()
    TxtItemsPrice.Text = Format(TxtItemsPrice.Text, "#,##0")
End Sub

' ?@?\?@?@?@: DirectIOEvent???m
'
' ???l?@?@: ???
'
' ?????@?@?@: Long ?C?x???gNo., Long pData, String pString
'
' ?@?\?????@: DirectIOEvent???n???h??????B
'
' ???l?@?@?@:
Private Sub OPOSCashChanger1_DirectIOEvent(ByVal EventNumber As Long, _
                                            pData As Long, pString As String)
   
    ' ?G???[???????????N???????????????I??
    If ERR_AUTO.Value = False Then Exit Sub
    
    If EventNumber = CHAN_DIEVT_DEPOSITERROR Then
        ' ?v???G???[???A?G???[?R?[?h???`?F?b?N????G???[?????K?C?_???X???N??
        iErrCode = CheckErrorCode
        If iErrCode > 0 Then
            Dim lngData As Long
            Dim lngRet As Long
            Dim strTemp As String
        
            '?????|?b?v?A?b?v
            lngData = 1
            
            ' ?\????u???????
            strTemp = GetErrGuidancePos()
        
            'DirectIO???\?b?h????s?i?G???[?????K?C?_???X??N???j
            gfncOposLog "DirectIO CHAN_DI_ERRGUIDANCE", True, "", Me.Name, "", ""
            lngRet = OPOSCashChanger1.DirectIO(CHAN_DI_ERRGUIDANCE, lngData, strTemp)
            gfncOposLog "DirectIO CHAN_DI_ERRGUIDANCE", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
        End If
    End If

End Sub

' ?@?\?@?@?@: StatusUpdateEvent???m
'
' ???l?@?@: ???
'
' ?????@?@?@: Long ?X?e?[?^?X
'
' ?@?\?????@: StatusUpdateEvent???n???h??????B
'
' ???l?@?@?@:
Private Sub OPOSCashChanger1_StatusUpdateEvent(ByVal Status As Long)

    ' ?G???[???????????N???????????????I??
    If ERR_AUTO.Value = False Then Exit Sub
   
    Dim iErrCode As Integer
    If Status = ChanStatusJam Then
        ' Jam???A?G???[?R?[?h???`?F?b?N????G???[?????K?C?_???X???N??
        iErrCode = CheckErrorCode
        If iErrCode > 0 Then
            Dim lngData As Long
            Dim lngRet As Long
            Dim strTemp As String
        
            '?????|?b?v?A?b?v
            lngData = 1
            
            ' ?\????u???????
            strTemp = GetErrGuidancePos()
        
            'DirectIO???\?b?h????s?i?G???[?????K?C?_???X??N???j
            gfncOposLog "DirectIO CHAN_DI_ERRGUIDANCE", True, "", Me.Name, "", ""
            lngRet = OPOSCashChanger1.DirectIO(CHAN_DI_ERRGUIDANCE, lngData, strTemp)
            gfncOposLog "DirectIO CHAN_DI_ERRGUIDANCE", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
        End If
    End If

End Sub
' ?@?\?@?@?@: ?????@?G???[?`?F?b?N
'
' ???l?@?@: Integer ?G???[?R?[?h(0:?G???[??????????????)
'
' ?????@?@?@: ???
'
' ?@?\?????@: ?????[?h????????G???[???????????????????????
'
' ???l?@?@?@: ?d??E?????????G???[????A?d????G???[?R?[?h???p??????B
Private Function CheckErrorCode() As Integer
    
    Dim lngData As Long
    Dim lngRet  As Long
    Dim strTemp  As String
    
    ' ??????
    CheckErrorCode = 0
        
    '??????????[?hNo.???
    If RAD_RT.Value = True Then
        lngData = &H80  ' ?????E?d??????
    Else
        lngData = &H1   ' ?d??P????
    End If

    'DirectIO???\?b?h????s?i?????[?h?j
    gfncOposLog "DirectIO CHAN_DI_STATUSREAD", True, "", Me.Name, "", ""
    lngRet = OPOSCashChanger1.DirectIO(CHAN_DI_STATUSREAD, lngData, strTemp)
    gfncOposLog "DirectIO CHAN_DI_STATUSREAD", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
    
    If lngRet = OposSuccess Then
        ' *** ?????[?h???X?|???X??G???[?R?[?h???`?F?b?N ***
        If RAD_RT.Value = True Then
            ' ????????A???d????G???[?R?[?h????
            CheckErrorCode = CInt(Mid(strTemp, 40, 4))
            If CheckErrorCode < 1 Then
                ' ?d????G???[?????????A??????????
                CheckErrorCode = CInt(Left(strTemp, 4))
            End If
        Else
            ' ?d??P??????
            CheckErrorCode = CInt(Left(strTemp, 4))
        End If
    End If

End Function
