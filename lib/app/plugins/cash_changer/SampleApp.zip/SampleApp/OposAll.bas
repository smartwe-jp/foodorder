Attribute VB_Name = "OposAll"
Rem *///////////////////////////////////////////////////////////////////
Rem *///////////////////////////////////////////////////////////////////
Rem *///////////////////////////////////////////////////////////////////
Rem *
Rem * OPOSALL.BAS
Rem *
Rem *   Includes all OPOS Device Classes.
Rem *
Rem * Modification history
Rem * ------------------------------------------------------------------
Rem * 96-03-18 OPOS Release 1.01                                    CRM
Rem * 96-04-22 OPOS Release 1.1                                     CRM
Rem * 97-06-04 OPOS Release 1.2                                     CRM
Rem * 98-03-06 OPOS Release 1.3                                     CRM
Rem * 99-06-18 OPOS Release 1.4 and 1.5                             CRM
Rem * 00-09-24 OPOS Release 1.5                                     BKS
Rem * 01-07-15 OPOS Release 1.6                                 THH/BKS
Rem *
Rem *  Note: This file is not actively maintained.
Rem *        The recommended source of up-to-date constants is the
Rem *          file Opos_Constants.dll. Add a reference to it, then
Rem *          use VB's Object Browser to find the constants.
Rem *
Rem *///////////////////////////////////////////////////////////////////
Rem *///////////////////////////////////////////////////////////////////
Rem *///////////////////////////////////////////////////////////////////



Rem *///////////////////////////////////////////////////////////////////
Rem *
Rem * Opos.h
Rem *
Rem *   General header file for OPOS Applications.
Rem *
Rem * Modification history
Rem * ------------------------------------------------------------------
Rem * 95-12-08 OPOS Release 1.0                                     CRM
Rem * 97-06-04 OPOS Release 1.2               MtD                      CRM
Rem *   Add OPOS_FOREVER.
Rem *   Add BinaryConversion values.
Rem * 98-03-06 OPOS Release 1.3                                     CRM
Rem *   Add CapPowerReporting, PowerState, and PowerNotify values.
Rem *   Add power reporting values for StatusUpdateEvent.
Rem * 00-09-24 OPOS Release 1.5                                     CRM
Rem *   Add OpenResult status values.
Rem * 00-07-18 OPOS Release 1.5                                     BKS
Rem *   Add many values and Point Card Reader Writer and
Rem *   POS Power sections.
Rem *
Rem *///////////////////////////////////////////////////////////////////


Rem *///////////////////////////////////////////////////////////////////
Rem * OPOS "State" Property Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const OposSClosed& = 1
Public Const OposSIdle& = 2
Public Const OposSBusy& = 3
Public Const OposSError& = 4


Rem *///////////////////////////////////////////////////////////////////
Rem * OPOS "ResultCode" Property Constants
Rem *///////////////////////////////////////////////////////////////////
Public Const OPOSERREXT& = 200

Public Const OposSuccess& = 0
Public Const OposEClosed& = 101
Public Const OposEClaimed& = 102
Public Const OposENotclaimed& = 103
Public Const OposENoservice& = 104
Public Const OposEDisabled& = 105
Public Const OposEIllegal& = 106
Public Const OposENohardware& = 107
Public Const OposEOffline& = 108
Public Const OposENoexist& = 109
Public Const OposEExists& = 110
Public Const OposEFailure& = 111
Public Const OposETimeout& = 112
Public Const OposEBusy& = 113
Public Const OposEExtended& = 114


Rem *///////////////////////////////////////////////////////////////////
Rem * OPOS "OpenResult" Property Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const Oposopenerr& = 300

Public Const OposOrAlreadyopen& = 301
Public Const OposOrRegbadname& = 302
Public Const OposOrRegprogid& = 303
Public Const OposOrCreate& = 304
Public Const OposOrBadif& = 305
Public Const OposOrFailedopen& = 306
Public Const OposOrBadversion& = 307

Public Const Oposopenerrso& = 400

Public Const OposOrsNoport = 401
Public Const OposOrsNotsupported = 402
Public Const OposOrsConfig = 403
Public Const OposOrsSpecific = 450


Rem *///////////////////////////////////////////////////////////////////
Rem * OPOS "BinaryConversion" Property Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const OposBcNone& = 0
Public Const OposBcNibble& = 1
Public Const OposBcDecimal& = 2


Rem *///////////////////////////////////////////////////////////////////
Rem * "CheckHealth" Method: "Level" Parameter Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const OposChInternal& = 1
Public Const OposChExternal& = 2
Public Const OposChInteractive& = 3


Rem *///////////////////////////////////////////////////////////////////
Rem * OPOS "CapPowerReporting", "PowerState", "PowerNotify" Property
Rem *   Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const OposPrNone& = 0
Public Const OposPrStandard& = 1
Public Const OposPrAdvanced& = 2

Public Const OposPnDisabled& = 0
Public Const OposPnEnabled& = 1

Public Const OposPsUnknown& = 2000
Public Const OposPsOnline& = 2001
Public Const OposPsOff& = 2002
Public Const OposPsOffline& = 2003
Public Const OposPsOffOffline& = 2004


Rem *///////////////////////////////////////////////////////////////////
Rem * "ErrorEvent" Event: "ErrorLocus" Parameter Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const OposElOutput& = 1
Public Const OposElInput& = 2
Public Const OposElInputData& = 3


Rem *///////////////////////////////////////////////////////////////////
Rem * "ErrorEvent" Event: "ErrorResponse" Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const OposErRetry& = 11
Public Const OposErClear& = 12
Public Const OposErContinueinput& = 13


Rem *///////////////////////////////////////////////////////////////////
Rem * "StatusUpdateEvent" Event: Common "Status" Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const OposSuePowerOnline& = 2001
Public Const OposSuePowerOff& = 2002
Public Const OposSuePowerOffline& = 2003
Public Const OposSuePowerOffOffline& = 2004


Rem *///////////////////////////////////////////////////////////////////
Rem * General Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const OposForever& = -1


Rem *///////////////////////////////////////////////////////////////////
Rem *
Rem * OposChan.h
Rem *
Rem *   Cash Changer header file for OPOS Applications.
Rem *
Rem * Modification history
Rem * ------------------------------------------------------------------
Rem * 97-06-04 OPOS Release 1.2                                     CRM
Rem * 00-09-24 OPOS Release 1.5                                  OPOS-J
Rem *   Add DepositStatus Constants.
Rem *   Add EndDeposit Constants.
Rem *   Add PauseDeposit Constants.
Rem *
Rem *///////////////////////////////////////////////////////////////////


Rem *///////////////////////////////////////////////////////////////////
Rem * "DeviceStatus" and "FullStatus" Property Constants
Rem * "StatusUpdateEvent" Event Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const ChanStatusOk& = 0                         ' DeviceStatus, FullStatus

Public Const ChanStatusEmpty& = 11                     ' DeviceStatus, StatusUpdateEvent
Public Const ChanStatusNearempty& = 12                 ' DeviceStatus, StatusUpdateEvent
Public Const ChanStatusEmptyok& = 13                   ' StatusUpdateEvent

Public Const ChanStatusFull& = 21                      ' FullStatus, StatusUpdateEvent
Public Const ChanStatusNearfull& = 22                  ' FullStatus, StatusUpdateEvent
Public Const ChanStatusFullok& = 23                    ' StatusUpdateEvent

Public Const ChanStatusJam& = 31                       ' DeviceStatus, StatusUpdateEvent
Public Const ChanStatusJamok& = 32                     ' StatusUpdateEvent

Public Const ChanStatusAsync& = 91                     ' StatusUpdateEvent


Rem *///////////////////////////////////////////////////////////////////
Rem * "DepositStatus" Property Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const ChanStatusDepositStart& = 1
Public Const ChanStatusDepositEnd& = 2
Public Const ChanStatusDepositNone& = 3
Public Const ChanStatusDepositCount& = 4
Public Const ChanStatusDepositJam& = 5


Rem *///////////////////////////////////////////////////////////////////
Rem * "EndDeposit" Property Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const ChanDepositChange& = 1
Public Const ChanDepositNochange& = 2
Public Const ChanDepositrepay& = 3


Rem *///////////////////////////////////////////////////////////////////
Rem * "PauseDeposit" Property Constants
Rem *///////////////////////////////////////////////////////////////////

Public Const ChanDepositPause& = 11
Public Const ChanDepositRestart& = 12


Rem *///////////////////////////////////////////////////////////////////
Rem * "ResultCodeExtended" Property Constants for Cash Changer
Rem *///////////////////////////////////////////////////////////////////

Public Const OposEchanOverdispense& = 201



Rem *End of OPOSALL.BAS*
