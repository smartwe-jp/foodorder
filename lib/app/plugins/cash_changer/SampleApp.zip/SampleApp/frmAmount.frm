VERSION 5.00
Begin VB.Form frmAmount 
   BorderStyle     =   3  '�Œ��޲�۸�
   Caption         =   "�ޑK�@�ݍ�"
   ClientHeight    =   6990
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   8490
   ClipControls    =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6990
   ScaleWidth      =   8490
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  '��ʂ̒���
   Begin VB.CommandButton Command1 
      Caption         =   "�߁@��"
      BeginProperty Font 
         Name            =   "�l�r �S�V�b�N"
         Size            =   14.25
         Charset         =   128
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   5760
      TabIndex        =   3
      Top             =   6240
      Width           =   2415
   End
   Begin VB.Label lblAmount 
      BeginProperty Font 
         Name            =   "�l�r �S�V�b�N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5775
      Index           =   2
      Left            =   5640
      TabIndex        =   2
      Top             =   120
      Width           =   2415
   End
   Begin VB.Label lblAmount 
      BeginProperty Font 
         Name            =   "�l�r �S�V�b�N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5775
      Index           =   1
      Left            =   2880
      TabIndex        =   1
      Top             =   120
      Width           =   2415
   End
   Begin VB.Label lblAmount 
      BeginProperty Font 
         Name            =   "�l�r �S�V�b�N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5775
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   2415
   End
End
Attribute VB_Name = "frmAmount"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub StartUp_Click()
    Unload Me
End Sub

Private Sub Form_Load()
    Dim strTemp As String
        
    strTemp = "���[���ݍ�" & vbCrLf
    strTemp = strTemp & "�@�@���~�F�@" & Format(mlngCashCount(GE_CASHTYPE_10000), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�ܐ�~�F�@" & Format(mlngCashCount(GE_CASHTYPE_5000), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@���~�F�@" & Format(mlngCashCount(GE_CASHTYPE_2000), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�@��~�F�@" & Format(mlngCashCount(GE_CASHTYPE_1000), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@ 500�~�F�@" & Format(mlngCashCount(GE_CASHTYPE_500), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@ 100�~�F�@" & Format(mlngCashCount(GE_CASHTYPE_100), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�@50�~�F�@" & Format(mlngCashCount(GE_CASHTYPE_50), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�@10�~�F�@" & Format(mlngCashCount(GE_CASHTYPE_10), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�@ 5�~�F�@" & Format(mlngCashCount(GE_CASHTYPE_5), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�@ 1�~�F�@" & Format(mlngCashCount(GE_CASHTYPE_1), "#,##0") & "��"
    
    lblAmount(0).Caption = strTemp
    
    strTemp = "�J�Z�b�g���ݍ�" & vbCrLf
    strTemp = strTemp & "�@�@���~�F�@" & Format(mlngCassetteCount(GE_CASHTYPE_10000), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�ܐ�~�F�@" & Format(mlngCassetteCount(GE_CASHTYPE_5000), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@���~�F�@" & Format(mlngCassetteCount(GE_CASHTYPE_2000), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�@��~�F�@" & Format(mlngCassetteCount(GE_CASHTYPE_1000), "#,##0") & "��"
    
    lblAmount(1).Caption = strTemp
    
    strTemp = "�I�[�o�[�t���[�ݍ�" & vbCrLf
    strTemp = strTemp & "�@ 500�~�F�@" & Format(mlngOverflowCount(GE_CASHTYPE_500), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@ 100�~�F�@" & Format(mlngOverflowCount(GE_CASHTYPE_100), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�@50�~�F�@" & Format(mlngOverflowCount(GE_CASHTYPE_50), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�@10�~�F�@" & Format(mlngOverflowCount(GE_CASHTYPE_10), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�@ 5�~�F�@" & Format(mlngOverflowCount(GE_CASHTYPE_5), "#,##0") & "��" & vbCrLf
    strTemp = strTemp & "�@�@ 1�~�F�@" & Format(mlngOverflowCount(GE_CASHTYPE_1), "#,##0") & "��"
        
    lblAmount(2).Caption = strTemp

End Sub
