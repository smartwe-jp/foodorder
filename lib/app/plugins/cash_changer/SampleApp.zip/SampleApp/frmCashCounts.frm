VERSION 5.00
Begin VB.Form frmCashCounts 
   BorderStyle     =   3  '?��Œ�?��޲?��۸?��
   Caption         =   "?��@?��?��?��ݍ�"
   ClientHeight    =   4800
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7035
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   320
   ScaleMode       =   3  '?��߸?��?��
   ScaleWidth      =   469
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows ?��̊�?��?��l
   Begin VB.CommandButton BtnBack 
      Caption         =   "?��߂�"
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   9.75
         Charset         =   128
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4800
      TabIndex        =   23
      Top             =   4200
      Width           =   1815
   End
   Begin VB.TextBox TxtCoinMai 
      Alignment       =   1  '?��E?��?��?��?��
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   5
      Left            =   5520
      TabIndex        =   22
      Top             =   1080
      Width           =   855
   End
   Begin VB.TextBox TxtCoinMai 
      Alignment       =   1  '?��E?��?��?��?��
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   5520
      TabIndex        =   21
      Top             =   2040
      Width           =   855
   End
   Begin VB.TextBox TxtCoinMai 
      Alignment       =   1  '?��E?��?��?��?��
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   5520
      TabIndex        =   20
      Top             =   2520
      Width           =   855
   End
   Begin VB.TextBox TxtCoinMai 
      Alignment       =   1  '?��E?��?��?��?��
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   5520
      TabIndex        =   19
      Top             =   3000
      Width           =   855
   End
   Begin VB.TextBox TxtCoinMai 
      Alignment       =   1  '?��E?��?��?��?��
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   5520
      TabIndex        =   18
      Top             =   3480
      Width           =   855
   End
   Begin VB.TextBox TxtCoinMai 
      Alignment       =   1  '?��E?��?��?��?��
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   4
      Left            =   5520
      TabIndex        =   17
      Top             =   1560
      Width           =   855
   End
   Begin VB.TextBox TxtBillMai 
      Alignment       =   1  '?��E?��?��?��?��
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   2040
      TabIndex        =   14
      Top             =   1560
      Width           =   855
   End
   Begin VB.TextBox TxtBillMai 
      Alignment       =   1  '?��E?��?��?��?��
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   2040
      TabIndex        =   13
      Top             =   2040
      Width           =   855
   End
   Begin VB.TextBox TxtBillMai 
      Alignment       =   1  '?��E?��?��?��?��
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   2040
      TabIndex        =   12
      Top             =   2520
      Width           =   855
   End
   Begin VB.TextBox TxtBillMai 
      Alignment       =   1  '?��E?��?��?��?��
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   2040
      TabIndex        =   11
      Top             =   1080
      Width           =   855
   End
   Begin VB.Label Label2 
      Caption         =   "       ?��?��   ?��?��               ?��?��  ?��?��     "
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   9.75
         Charset         =   128
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   3840
      TabIndex        =   16
      Top             =   720
      Width           =   2895
   End
   Begin VB.Label Label3 
      Caption         =   "       ?��?��   ?��?��               ?��?��  ?��?��     "
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   9.75
         Charset         =   128
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   360
      TabIndex        =   15
      Top             =   720
      Width           =   2895
   End
   Begin VB.Label lblCoinkinsyu 
      Alignment       =   1  '?��E?��?��?��?��
      BorderStyle     =   1  '?��?��?��?��
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Index           =   5
      Left            =   3840
      TabIndex        =   10
      Top             =   1080
      Width           =   1440
   End
   Begin VB.Label lblCoinkinsyu 
      Alignment       =   1  '?��E?��?��?��?��
      BorderStyle     =   1  '?��?��?��?��
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Index           =   3
      Left            =   3840
      TabIndex        =   9
      Top             =   2040
      Width           =   1440
   End
   Begin VB.Label lblCoinkinsyu 
      Alignment       =   1  '?��E?��?��?��?��
      BorderStyle     =   1  '?��?��?��?��
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Index           =   2
      Left            =   3840
      TabIndex        =   8
      Top             =   2520
      Width           =   1440
   End
   Begin VB.Label lblCoinkinsyu 
      Alignment       =   1  '?��E?��?��?��?��
      BorderStyle     =   1  '?��?��?��?��
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Index           =   1
      Left            =   3840
      TabIndex        =   7
      Top             =   3000
      Width           =   1440
   End
   Begin VB.Label lblCoinkinsyu 
      Alignment       =   1  '?��E?��?��?��?��
      BorderStyle     =   1  '?��?��?��?��
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Index           =   0
      Left            =   3840
      TabIndex        =   6
      Top             =   3480
      Width           =   1440
   End
   Begin VB.Label lblCoinkinsyu 
      Alignment       =   1  '?��E?��?��?��?��
      BorderStyle     =   1  '?��?��?��?��
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Index           =   4
      Left            =   3840
      TabIndex        =   5
      Top             =   1560
      Width           =   1440
   End
   Begin VB.Label lblBillkinsyu 
      Alignment       =   1  '?��E?��?��?��?��
      BorderStyle     =   1  '?��?��?��?��
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Index           =   3
      Left            =   360
      TabIndex        =   4
      Top             =   1080
      Width           =   1440
   End
   Begin VB.Label lblBillkinsyu 
      Alignment       =   1  '?��E?��?��?��?��
      BorderStyle     =   1  '?��?��?��?��
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Index           =   2
      Left            =   360
      TabIndex        =   3
      Top             =   1560
      Width           =   1440
   End
   Begin VB.Label lblBillkinsyu 
      Alignment       =   1  '?��E?��?��?��?��
      BorderStyle     =   1  '?��?��?��?��
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Index           =   1
      Left            =   360
      TabIndex        =   2
      Top             =   2040
      Width           =   1440
   End
   Begin VB.Label lblBillkinsyu 
      Alignment       =   1  '?��E?��?��?��?��
      BorderStyle     =   1  '?��?��?��?��
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   12
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Index           =   0
      Left            =   360
      TabIndex        =   1
      Top             =   2520
      Width           =   1440
   End
   Begin VB.Label Label1 
      Alignment       =   2  '?��?��?��?��?��?��?��?��
      BackColor       =   &H00FF0000&
      BorderStyle     =   1  '?��?��?��?��
      Caption         =   "?��@?��?��?��ݍ�?��\?��?��"
      BeginProperty Font 
         Name            =   "?��l?��r ?��o?��S?��V?��b?��N"
         Size            =   15.75
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FFFF&
      Height          =   435
      Left            =   315
      TabIndex        =   0
      Top             =   120
      Width           =   6465
   End
End
Attribute VB_Name = "frmCashCounts"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub BtnBack_Click()
    Unload Me   '?��_?��C?��A?��?��?��O?��?���?��?��
End Sub

