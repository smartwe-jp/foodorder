VERSION 5.00
Begin VB.Form frmReturn 
   Caption         =   "???????"
   ClientHeight    =   2655
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5310
   BeginProperty Font 
      Name            =   "?l?r ?o?S?V?b?N"
      Size            =   15.75
      Charset         =   128
      Weight          =   700
      Underline       =   0   'False
      Italic          =   -1  'True
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   2655
   ScaleWidth      =   5310
   StartUpPosition =   3  'Windows ?????l
   Begin VB.CommandButton BtnCancel 
      Caption         =   "?L?????Z??"
      BeginProperty Font 
         Name            =   "?l?r ?o?S?V?b?N"
         Size            =   12
         Charset         =   128
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   2880
      TabIndex        =   4
      Top             =   1920
      Width           =   1935
   End
   Begin VB.CommandButton BtnReturn 
      Caption         =   "???"
      BeginProperty Font 
         Name            =   "?l?r ?o?S?V?b?N"
         Size            =   12
         Charset         =   128
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   600
      TabIndex        =   3
      Top             =   1920
      Width           =   1935
   End
   Begin VB.TextBox TxtReturnAmount 
      Alignment       =   1  '?E????
      BeginProperty Font 
         Name            =   "?l?r ?o?S?V?b?N"
         Size            =   21.75
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   600
      TabIndex        =   1
      Top             =   960
      Width           =   3375
   End
   Begin VB.Label Label2 
      Caption         =   "?~"
      BeginProperty Font 
         Name            =   "?l?r ?o?S?V?b?N"
         Size            =   15.75
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4200
      TabIndex        =   2
      Top             =   1200
      Width           =   615
   End
   Begin VB.Label Label1 
      Alignment       =   2  '????????
      BackColor       =   &H00C00000&
      Caption         =   "??????v?z???????????????"
      BeginProperty Font 
         Name            =   "?l?r ?o?S?V?b?N"
         Size            =   15.75
         Charset         =   128
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0080FFFF&
      Height          =   315
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   4800
   End
End
Attribute VB_Name = "frmReturn"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub BtnCancel_Click()
    Unload Me   '?_?C?A???O??????

End Sub

Private Sub Form_Load()
    TxtReturnAmount.Text = 0  '?e?L?X?g?{?b?N?X???????
    
End Sub

' ?@?\?@?@?@: ???????????s
'
' ???l?@?@: Boolean, True(????) or False(???s)
'
' ?????@?@?@: ???
'
' ?@?\?????@: ????????i?o???j???J?n????
'
' ???l?@?@?@:

Private Sub BtnReturn_Click()
    Dim lngRet As Long
    Dim lngChange As Long

    If frmMain.OPOSCashChanger1 Is Nothing Then
        Exit Sub
    End If
    
    lngChange = CLng(TxtReturnAmount.Text)
    
    If lngChange <= 0 Then
        lngAmount = 0
        '?t?H?[????\???X?V????
        frmMain.TxtItemsPrice.Text = 0
        frmMain.TxtDepositAmount.Text = 0
        frmMain.BtnClosure.Enabled = True
        frmMain.BtnBatchCollection.Enabled = True
        Exit Sub
    End If
    
    '?v???p?e?B????i?????o????????i?o????:1?j?j
    frmMain.OPOSCashChanger1.CurrentExit = 1
    
    'DispenseChange???\?b?h????s?i?????o???????i???z?w??j?j
    gfncOposLog "DispenseChange", True, lngChange, Me.Name, "", ""
    lngRet = frmMain.OPOSCashChanger1.DispenseChange(lngChange)
    gfncOposLog "DispenseChange", False, "????R?[?h?F" & lngRet, Me.Name, "", ""
    
    '???o?????I??
    Select Case lngRet
    Case OposSuccess
        menmStatus = GE_CASHCHANGER_STATUS_CONNECT
        lngAmSuccessount = 0
        '?t?H?[????\???X?V????
        frmMain.TxtItemsPrice.Text = 0
        frmMain.TxtDepositAmount.Text = 0
        frmMain.BtnClosure.Enabled = True
        frmMain.BtnBatchCollection.Enabled = True
    Case Else
        menmErrStatus = GE_CASHCHANGER_ERROR_ELSE
    End Select
    
    Unload Me   '?_?C?A???O??????

End Sub

