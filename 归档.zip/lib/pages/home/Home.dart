
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class HomePage extends StatefulWidget {
  HomePage({Key key}) : super(key: key);

  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  @override
  void initState() {
    super.initState();


  }


  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();

  }



  @override
  Widget build(BuildContext context) {
    //ScreenAdapter.init(context);
    //显示底部栏(隐藏顶部状态栏)
//    SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.bottom]);
    //显示顶部栏(隐藏底部栏)
//    SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.top]);
    //隐藏底部栏和顶部状态栏
    //SystemChrome.setEnabledSystemUIOverlays([]);

    return Scaffold(

      body: Container(
        padding: EdgeInsets.only(top: 50),
        child: Column(
          children: [
            InkWell(
              onTap: (){
                Navigator.pushNamed(
                  context,
                  '/scanPay',
                );
              },
              child: Text("扫描二维码"),
            ),

            InkWell(
              onTap: (){
                Navigator.pushNamed(
                  context,
                  '/menuPage',
                );
              },
              child: Text("查看菜单"),
            ),
            InkWell(
              onTap: (){
                Navigator.pushNamed(
                  context,
                  '/showImage',
                );
              },
              child: Text("查看图片"),
            ),
          ],
        ),
      ),

    );
  }
}
