
import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:foodorder/config/index.dart';
import 'package:foodorder/services/ScreenAdapter.dart';
import 'package:foodorder/services/SqfliteHelper.dart';
import 'package:http/http.dart' as http;

class MenuPage extends StatefulWidget {
  MenuPage({Key key}) : super(key: key);

  _MenuPageState createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {

  final sqlHelper = SqfliteHelper();
  @override
  void initState() {
    super.initState();


  }


  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();

  }

  getAllPost() async{
    await sqlHelper.open();
    return await sqlHelper.queryAll();
  }

  deleteitem(id) async{
    await sqlHelper.delete(id);
    setState(() {

    });
  }



  @override
  Widget build(BuildContext context) {
    //ScreenAdapter.init(context);
    //显示底部栏(隐藏顶部状态栏)
//    SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.bottom]);
    //显示顶部栏(隐藏底部栏)
//    SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.top]);
    //隐藏底部栏和顶部状态栏
    //SystemChrome.setEnabledSystemUIOverlays([]);

    return Scaffold(
      /*floatingActionButton: FloatingActionButton(
        child: Icon(Icons.http),
        onPressed: (){
          loaddata();
        },

      ),*/
      body: FutureBuilder(
        future: getAllPost(),
        builder: (context, snap){
          if(snap.hasData){
            List l = snap.data;
            return ListView.builder(
                itemCount: l.length,
                itemBuilder: (context, idx){
                  return InkWell(
                    onTap: (){
                      deleteitem(l[idx]['id']);
                    },
                    child: ListTile(title: Text(l[idx]['title']),),
                  );
                });
          }
        },),


    );
  }
}
